/*
 * File:   main.c
 * Author: DELL
 *
 * Created on 19 July, 2025, 11:30 AM
 */
#include <xc.h>
#include "digital_keypad.h"
#include "timer0.h"
#include "main.h"
#include "uart.h"

#define IND_LEFT_KEY   SWITCH1
#define IND_RIGHT_KEY  SWITCH2
#define HAZARD_KEY     0x0C

#define LED_LEFT       RB6
#define LED_RIGHT      RB7

#define LED_ACTIVE     1
#define LED_IDLE       0

unsigned short system_tick = 0;
unsigned short key_hold_counter = 0;
unsigned short led_flash_counter = 0;
unsigned short uart_print_timer = 0;

unsigned char left_mode = 0;
unsigned char right_mode = 0;
unsigned char hazard_mode = 0;

unsigned char placeholder_char;

static void initialize_all(void)
{
    PEIE = 1;
    LED_LEFT = LED_IDLE;
    LED_RIGHT = LED_IDLE;
    TRISB6 = 0;
    TRISB7 = 0;

    init_digital_keypad();
    init_timer0();
    init_uart();
    GIE = 1;
}

void main(void)
{
    short last_tick_snapshot = 0;
    initialize_all();

    while (1)
    {
        unsigned char key_pressed = read_digital_keypad(LEVEL);

        if (last_tick_snapshot != system_tick)
        {
            last_tick_snapshot = system_tick;
            key_hold_counter++;
            uart_print_timer++;
            led_flash_counter++;
            if (system_tick == 1250)
                system_tick = 0;
        }

        if (key_pressed != 0x0F)
        {
            if (key_hold_counter == 1250)
            {
                LED_LEFT = LED_RIGHT = LED_IDLE;
                led_flash_counter = 0;
                key_hold_counter++;
                uart_print_timer++;

                if (key_pressed == IND_LEFT_KEY)
                {
                    if (hazard_mode)
                        hazard_mode = 0;
                    else
                    {
                        left_mode = !left_mode;
                        right_mode = 0;
                    }
                }
                else if (key_pressed == IND_RIGHT_KEY)
                {
                    if (hazard_mode)
                        hazard_mode = 0;
                    else
                    {
                        right_mode = !right_mode;
                        left_mode = 0;
                    }
                }
                else if (key_pressed == HAZARD_KEY)
                {
                    hazard_mode = !hazard_mode;
                    left_mode = right_mode = 0;
                }
            }
            if (key_hold_counter == 1253)
                key_hold_counter = 1251;
        }
        else
        {
            key_hold_counter = 0;
        }

        if (!hazard_mode && !left_mode && !right_mode)
            led_flash_counter = 0;

        if (led_flash_counter == 375)
            led_flash_counter = 0;

        if (led_flash_counter < 125) // LED ON Phase
        {
            if (hazard_mode)
            {
                LED_LEFT = LED_ACTIVE;
                LED_RIGHT = LED_ACTIVE;
            }
            else if (left_mode)
            {
                LED_LEFT = LED_ACTIVE;
            }
            else if (right_mode)
            {
                LED_RIGHT = LED_ACTIVE;
            }
        }
        else if (led_flash_counter < 250) // LED OFF Phase
        {
            LED_LEFT = LED_IDLE;
            LED_RIGHT = LED_IDLE;
        }
        else // LED ON again
        {
            if (hazard_mode)
            {
                LED_LEFT = LED_ACTIVE;
                LED_RIGHT = LED_ACTIVE;
            }
            else if (left_mode)
            {
                LED_LEFT = LED_ACTIVE;
            }
            else if (right_mode)
            {
                LED_RIGHT = LED_ACTIVE;
            }
        }

        if (uart_print_timer == 1250)
        {
            uart_print_timer = 0;

            if (left_mode)
            {
                puts("LEFT INDICATOR ACTIVE\n\r");
            }
            else if (right_mode)
            {
                puts("RIGHT INDICATOR ACTIVE\n\r");
            }
            else if (hazard_mode)
            {
                puts("HAZARD MODE ACTIVE\n\r");
            }
            else
            {
                puts("ALL INDICATORS OFF\n\r");
            }
        }
    }
}
