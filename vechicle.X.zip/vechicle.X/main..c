/*
 * File:   main..c
 * Author: DELL
 *
 * Created on 19 July, 2025, 6:00 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#include "timer0.h"
#include "main.h"
#include "uart.h"
//digital keypad switches
#define IND_LEFT_KEY   SWITCH1   
#define IND_RIGHT_KEY  SWITCH2
#define HAZARD_KEY     0x0C

#define LED_LEFT       RB6  //led 6
#define LED_RIGHT      RB7  //led 7

#define LED_ACTIVE     1    //on
#define LED_IDLE       0    //off

unsigned short system_tick = 0;    //increment every 1ms
unsigned short key_hold_counter = 0;   //counts how long key is pressed
unsigned short led_flash_counter = 0;  //controls led blinking(on/off every 300ms)
unsigned short uart_print_timer = 0;   //for every 1.25s print
//modes
unsigned char left_mode = 0;    
unsigned char right_mode = 0;   
unsigned char hazard_mode = 0;

unsigned char placeholder_char;

static void initialize_all(void)
{
    PEIE = 1;     //enable peripheral interrupt
    //turn off leds initially
    LED_LEFT = LED_IDLE;   
    LED_RIGHT = LED_IDLE;
    TRISB6 = 0;    //set b6 as output
    TRISB7 = 0;    //set  b7 as output

    init_digital_keypad();   //for digital keypad
    init_timer0();            //for timer0
    init_uart();            //uart for data
    GIE = 1;                 //global interrupt enable
} 

void main(void)
{
    short last_tick = 0;    //keeps track of previous tick
    initialize_all();

    while (1)
    {
        unsigned char key_pressed = read_digital_keypad(LEVEL);  //to detect switch

        if (last_tick != system_tick)  
        {
            last_tick = system_tick;
            key_hold_counter++;
            uart_print_timer++;
            led_flash_counter++;
            if (system_tick == 1250)    //reset for every 1250 else overflow will occur
                system_tick = 0;
        }

        if (key_pressed != 0x0F)    //some key pressed
        {
            if (key_hold_counter == 1250)   //long press 
            {
                LED_LEFT = LED_RIGHT = LED_IDLE;
                led_flash_counter = 0;
                key_hold_counter++;
                uart_print_timer++;

                if (key_pressed == IND_LEFT_KEY)  //for left 
                {
                    if (hazard_mode)
                        hazard_mode = 0;  //off
                    else
                    {
                        left_mode = !left_mode;  //on
                        right_mode = 0;   //off
                    }
                }
                else if (key_pressed == IND_RIGHT_KEY)  //for right
                {
                    if (hazard_mode)
                        hazard_mode = 0;   //off
                    else
                    {
                        right_mode = !right_mode;   //on
                        left_mode = 0;   //off
                    }
                }
                else if (key_pressed == HAZARD_KEY)   //for both
                {
                    hazard_mode = !hazard_mode;    //on two leds
                    left_mode = right_mode = 0;   //off
                }
            }
            if (key_hold_counter == 1253)   //after 1.25s again press by mistakely reset it
                key_hold_counter = 1251;  //reset it
        }
        else
        {
            key_hold_counter = 0;   //if no switch pressed
        }

        if (!hazard_mode && !left_mode && !right_mode)   
            led_flash_counter = 0;

        if (led_flash_counter == 375)   //sets to 0
            led_flash_counter = 0;

        if (led_flash_counter < 125) // LED ON Phase
        {
            if (hazard_mode)
            {
                LED_LEFT = LED_ACTIVE;
                LED_RIGHT = LED_ACTIVE;
            }
            else if (left_mode)
            {
                LED_LEFT = LED_ACTIVE;
            }
            else if (right_mode)
            {
                LED_RIGHT = LED_ACTIVE;
            }
        }
        else if (led_flash_counter < 250) // LED OFF Phase
        {
            LED_LEFT = LED_IDLE;
            LED_RIGHT = LED_IDLE;
        }
        else // LED ON again
        {
            if (hazard_mode)
            {
                LED_LEFT = LED_ACTIVE;
                LED_RIGHT = LED_ACTIVE;
            }
            else if (left_mode)
            {
                LED_LEFT = LED_ACTIVE;
            }
            else if (right_mode)
            {
                LED_RIGHT = LED_ACTIVE;
            }
        }

        if (uart_print_timer == 1250)
        {
            uart_print_timer = 0;

            if (left_mode)
            {
                puts("LEFT INDICATOR ACTIVE\n\r");
            }
            else if (right_mode)
            {
                puts("RIGHT INDICATOR ACTIVE\n\r");
            }
            else if (hazard_mode)
            {
                puts("HAZARD MODE ACTIVE\n\r");
            }
            else
            {
                puts("ALL INDICATORS OFF\n\r");
            }
        }
    }
}
//0-124 ms ->ON
//125-249ms ->OFF
//250-374 ->ON
//375 -> OFF
