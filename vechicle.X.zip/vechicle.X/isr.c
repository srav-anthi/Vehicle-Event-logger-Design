/*
 * File:   isr.c
 * Author: DELL
 *
 * Created on 19 July, 2025, 11:38 AM
 */


#include <xc.h>
extern unsigned short system_tick;

void __interrupt() isr(void)
{
    if (TMR0IF)
    {
        TMR0IF = 0;
        TMR0 = TMR0 + 133;   //123 ticks will take until overflow
        system_tick++;
        
    }

}
//1000 ms -1 sec
//1250 ms -1.25 sec