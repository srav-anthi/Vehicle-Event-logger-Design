/*
 * File:   isr.c
 * Author: DELL
 *
 * Created on 19 July, 2025, 11:38 AM
 */


#include <xc.h>
extern unsigned short system_tick;

void __interrupt() isr(void)
{
    if (TMR0IF)
    {
        TMR0IF = 0;
        TMR0 = TMR0 + 133;
        system_tick++;
        
    }
}