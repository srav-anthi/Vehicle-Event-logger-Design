/*
 * File:   uart.c
 * Author: DELL
 *
 * Created on 19 July, 2025, 11:40 AM
 */


#include <xc.h>
#include "uart.h"

void init_uart(void)
{
	//Serial initialization 
	RX_PIN = 1;
	TX_PIN = 0;

	BRGH = 1;
	SPEN = 1;
	CREN = 1;
	
	SPBRG = 129;
//Interruot Enable Bit 
    RCIE = 1;


}

void putch(unsigned char byte) 
{
	while(!TXIF)
	{
		continue;
	}
	TXREG = byte;
}

int puts(const char *s)
{
	while(*s)		
	{
		putch(*s++);	
	}

	return 0;
}