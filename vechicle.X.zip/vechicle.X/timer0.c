/*
 * File:   timer0.c
 * Author: DELL
 *
 * Created on 19 July, 2025, 11:41 AM
 */


#include <xc.h>
#include "timer0.h"

void init_timer0(void)
{
	

//Set 8 bit timer register
	T08BIT = 1;
//internal clock selective
	T0CS = 0;

	TMR0ON = 1;

// disable prescaler
	PSA = 0;
    T0PS0 = 0;
    T0PS1 = 0;
    T0PS2 = 1;

	TMR0 = 131;

	//interrupt flag
	TMR0IF = 0;

	// Enable timer0 overflow interrupt 
	TMR0IE = 1;
}